package com.lifelinedb.service;

import com.lifelinedb.entity.Room;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    public List<Room> getAll() {
        return roomRepository.findAll();
    }

    public List<Room> getAvailable() {
        return roomRepository.findByStatus(Room.Status.AVAILABLE);
    }

    public Room getById(Long id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + id));
    }

    public Room create(Room room) {
        return roomRepository.save(room);
    }

    public Room update(Long id, Room updated) {
        Room existing = getById(id);
        existing.setRoomNumber(updated.getRoomNumber());
        existing.setRoomType(updated.getRoomType());
        existing.setStatus(updated.getStatus());
        existing.setPricePerDay(updated.getPricePerDay());
        return roomRepository.save(existing);
    }

    public void delete(Long id) {
        Room existing = getById(id);
        roomRepository.delete(existing);
    }
}
