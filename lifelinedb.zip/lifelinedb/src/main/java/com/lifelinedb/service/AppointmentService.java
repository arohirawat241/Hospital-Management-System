package com.lifelinedb.service;

import com.lifelinedb.entity.Appointment;
import com.lifelinedb.entity.Doctor;
import com.lifelinedb.entity.Patient;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.AppointmentRepository;
import com.lifelinedb.repository.DoctorRepository;
import com.lifelinedb.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    public List<Appointment> getAll() {
        return appointmentRepository.findAll();
    }

    public Appointment getById(Long id) {
        return appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + id));
    }

    public List<Appointment> getByPatient(Long patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    public List<Appointment> getByDoctor(Long doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    public Appointment create(Appointment appointment) {
        Long patientId = appointment.getPatient().getId();
        Long doctorId = appointment.getDoctor().getId();

        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + patientId));
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id: " + doctorId));

        appointment.setPatient(patient);
        appointment.setDoctor(doctor);
        return appointmentRepository.save(appointment);
    }

    public Appointment update(Long id, Appointment updated) {
        Appointment existing = getById(id);
        existing.setAppointmentDate(updated.getAppointmentDate());
        existing.setStatus(updated.getStatus());
        existing.setReason(updated.getReason());
        if (updated.getDoctor() != null) {
            Doctor doctor = doctorRepository.findById(updated.getDoctor().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));
            existing.setDoctor(doctor);
        }
        return appointmentRepository.save(existing);
    }

    public void delete(Long id) {
        Appointment existing = getById(id);
        appointmentRepository.delete(existing);
    }
}
