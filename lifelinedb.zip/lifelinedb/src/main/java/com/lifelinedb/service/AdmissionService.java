package com.lifelinedb.service;

import com.lifelinedb.entity.*;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Mirrors the room-status trigger described in the project report:
 * a room is marked OCCUPIED when a patient is admitted into it, and
 * AVAILABLE again once the patient is discharged.
 */
@Service
public class AdmissionService {

    @Autowired
    private AdmissionRepository admissionRepository;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    public List<Admission> getAll() {
        return admissionRepository.findAll();
    }

    public Admission getById(Long id) {
        return admissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Admission not found with id: " + id));
    }

    public List<Admission> getByPatient(Long patientId) {
        return admissionRepository.findByPatientId(patientId);
    }

    public List<Admission> getCurrentAdmissions() {
        return admissionRepository.findByDischargeDateIsNull();
    }

    @Transactional
    public Admission create(Admission admission) {
        Patient patient = patientRepository.findById(admission.getPatient().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));
        Room room = roomRepository.findById(admission.getRoom().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Room not found"));

        if (room.getStatus() != Room.Status.AVAILABLE) {
            throw new IllegalArgumentException("Room " + room.getRoomNumber() + " is not available");
        }

        admission.setPatient(patient);
        admission.setRoom(room);

        if (admission.getDoctor() != null && admission.getDoctor().getId() != null) {
            Doctor doctor = doctorRepository.findById(admission.getDoctor().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));
            admission.setDoctor(doctor);
        }

        admission.setStatus(Admission.Status.ADMITTED);

        // trigger-equivalent: occupy the room on admission
        room.setStatus(Room.Status.OCCUPIED);
        roomRepository.save(room);

        return admissionRepository.save(admission);
    }

    @Transactional
    public Admission discharge(Long id) {
        Admission admission = getById(id);
        if (admission.getDischargeDate() != null) {
            throw new IllegalArgumentException("Patient already discharged from this admission");
        }
        admission.setDischargeDate(LocalDateTime.now());
        admission.setStatus(Admission.Status.DISCHARGED);

        // trigger-equivalent: free up the room on discharge
        Room room = admission.getRoom();
        room.setStatus(Room.Status.AVAILABLE);
        roomRepository.save(room);

        return admissionRepository.save(admission);
    }

    public void delete(Long id) {
        Admission existing = getById(id);
        admissionRepository.delete(existing);
    }
}
