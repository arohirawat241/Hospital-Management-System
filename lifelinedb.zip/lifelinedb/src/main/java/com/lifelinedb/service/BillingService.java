package com.lifelinedb.service;

import com.lifelinedb.entity.Admission;
import com.lifelinedb.entity.Billing;
import com.lifelinedb.entity.Patient;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.AdmissionRepository;
import com.lifelinedb.repository.BillingRepository;
import com.lifelinedb.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BillingService {

    @Autowired
    private BillingRepository billingRepository;

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private AdmissionRepository admissionRepository;

    public List<Billing> getAll() {
        return billingRepository.findAll();
    }

    public Billing getById(Long id) {
        return billingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Billing record not found with id: " + id));
    }

    public List<Billing> getByPatient(Long patientId) {
        return billingRepository.findByPatientId(patientId);
    }

    public Billing create(Billing billing) {
        Patient patient = patientRepository.findById(billing.getPatient().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));
        billing.setPatient(patient);

        if (billing.getAdmission() != null && billing.getAdmission().getId() != null) {
            Admission admission = admissionRepository.findById(billing.getAdmission().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Admission not found"));
            billing.setAdmission(admission);
        } else {
            billing.setAdmission(null);
        }

        return billingRepository.save(billing);
    }

    public Billing update(Long id, Billing updated) {
        Billing existing = getById(id);
        existing.setAmount(updated.getAmount());
        existing.setBillingDate(updated.getBillingDate());
        existing.setPaymentStatus(updated.getPaymentStatus());
        return billingRepository.save(existing);
    }

    public void delete(Long id) {
        Billing existing = getById(id);
        billingRepository.delete(existing);
    }
}
