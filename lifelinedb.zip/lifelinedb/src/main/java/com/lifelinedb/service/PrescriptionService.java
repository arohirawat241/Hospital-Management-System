package com.lifelinedb.service;

import com.lifelinedb.entity.Appointment;
import com.lifelinedb.entity.Prescription;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.AppointmentRepository;
import com.lifelinedb.repository.PrescriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PrescriptionService {

    @Autowired
    private PrescriptionRepository prescriptionRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    public List<Prescription> getAll() {
        return prescriptionRepository.findAll();
    }

    public Prescription getById(Long id) {
        return prescriptionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Prescription not found with id: " + id));
    }

    public List<Prescription> getByAppointment(Long appointmentId) {
        return prescriptionRepository.findByAppointmentId(appointmentId);
    }

    public Prescription create(Prescription prescription) {
        Appointment appointment = appointmentRepository.findById(prescription.getAppointment().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found"));
        prescription.setAppointment(appointment);
        return prescriptionRepository.save(prescription);
    }

    public Prescription update(Long id, Prescription updated) {
        Prescription existing = getById(id);
        existing.setMedicineName(updated.getMedicineName());
        existing.setDosage(updated.getDosage());
        existing.setNotes(updated.getNotes());
        return prescriptionRepository.save(existing);
    }

    public void delete(Long id) {
        Prescription existing = getById(id);
        prescriptionRepository.delete(existing);
    }
}
