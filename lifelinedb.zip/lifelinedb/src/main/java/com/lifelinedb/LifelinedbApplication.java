package com.lifelinedb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifelinedbApplication {
    public static void main(String[] args) {
        SpringApplication.run(LifelinedbApplication.class, args);
    }
}
