package com.lifelinedb.controller;

import com.lifelinedb.entity.Prescription;
import com.lifelinedb.service.PrescriptionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/prescriptions")
public class PrescriptionController {

    @Autowired
    private PrescriptionService prescriptionService;

    @GetMapping
    public List<Prescription> getAll() {
        return prescriptionService.getAll();
    }

    @GetMapping("/{id}")
    public Prescription getById(@PathVariable Long id) {
        return prescriptionService.getById(id);
    }

    @GetMapping("/appointment/{appointmentId}")
    public List<Prescription> getByAppointment(@PathVariable Long appointmentId) {
        return prescriptionService.getByAppointment(appointmentId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Prescription create(@Valid @RequestBody Prescription prescription) {
        return prescriptionService.create(prescription);
    }

    @PutMapping("/{id}")
    public Prescription update(@PathVariable Long id, @Valid @RequestBody Prescription prescription) {
        return prescriptionService.update(id, prescription);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        prescriptionService.delete(id);
    }
}
