package com.lifelinedb.controller;

import com.lifelinedb.entity.Admission;
import com.lifelinedb.service.AdmissionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admissions")
public class AdmissionController {

    @Autowired
    private AdmissionService admissionService;

    @GetMapping
    public List<Admission> getAll() {
        return admissionService.getAll();
    }

    @GetMapping("/current")
    public List<Admission> getCurrent() {
        return admissionService.getCurrentAdmissions();
    }

    @GetMapping("/{id}")
    public Admission getById(@PathVariable Long id) {
        return admissionService.getById(id);
    }

    @GetMapping("/patient/{patientId}")
    public List<Admission> getByPatient(@PathVariable Long patientId) {
        return admissionService.getByPatient(patientId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Admission create(@Valid @RequestBody Admission admission) {
        return admissionService.create(admission);
    }

    @PutMapping("/{id}/discharge")
    public Admission discharge(@PathVariable Long id) {
        return admissionService.discharge(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        admissionService.delete(id);
    }
}
