package com.lifelinedb.controller;

import com.lifelinedb.entity.Billing;
import com.lifelinedb.service.BillingService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/billing")
public class BillingController {

    @Autowired
    private BillingService billingService;

    @GetMapping
    public List<Billing> getAll() {
        return billingService.getAll();
    }

    @GetMapping("/{id}")
    public Billing getById(@PathVariable Long id) {
        return billingService.getById(id);
    }

    @GetMapping("/patient/{patientId}")
    public List<Billing> getByPatient(@PathVariable Long patientId) {
        return billingService.getByPatient(patientId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Billing create(@Valid @RequestBody Billing billing) {
        return billingService.create(billing);
    }

    @PutMapping("/{id}")
    public Billing update(@PathVariable Long id, @Valid @RequestBody Billing billing) {
        return billingService.update(id, billing);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        billingService.delete(id);
    }
}
