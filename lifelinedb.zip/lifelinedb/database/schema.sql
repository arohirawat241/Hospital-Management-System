-- ============================================================
-- LifeLineDB - Reference schema (MySQL)
-- This mirrors what Hibernate will generate automatically via
-- spring.jpa.hibernate.ddl-auto=update, but is included so the
-- constraints/triggers/views called out in the project report
-- are explicit and can be run/inspected independently.
-- ============================================================

CREATE DATABASE IF NOT EXISTS lifelinedb;
USE lifelinedb;

-- ---------------- Departments ----------------
CREATE TABLE IF NOT EXISTS department (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255)
);

-- ---------------- Doctors ----------------
CREATE TABLE IF NOT EXISTS doctor (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    specialization VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100) UNIQUE,
    department_id BIGINT,
    CONSTRAINT fk_doctor_department FOREIGN KEY (department_id)
        REFERENCES department(id) ON DELETE SET NULL
);

-- ---------------- Patients ----------------
CREATE TABLE IF NOT EXISTS patient (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    gender VARCHAR(10),
    phone VARCHAR(20),
    address VARCHAR(255),
    email VARCHAR(100)
);

-- ---------------- Rooms ----------------
CREATE TABLE IF NOT EXISTS room (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(20) NOT NULL UNIQUE,
    room_type VARCHAR(50),
    status VARCHAR(20) NOT NULL DEFAULT 'AVAILABLE',
    price_per_day DECIMAL(10,2) NOT NULL
);

-- ---------------- Appointments ----------------
CREATE TABLE IF NOT EXISTS appointment (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    patient_id BIGINT NOT NULL,
    doctor_id BIGINT NOT NULL,
    appointment_date DATETIME NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'SCHEDULED',
    reason VARCHAR(255),
    CONSTRAINT fk_appt_patient FOREIGN KEY (patient_id) REFERENCES patient(id) ON DELETE CASCADE,
    CONSTRAINT fk_appt_doctor FOREIGN KEY (doctor_id) REFERENCES doctor(id) ON DELETE CASCADE
);

-- ---------------- Admissions ----------------
CREATE TABLE IF NOT EXISTS admission (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    patient_id BIGINT NOT NULL,
    room_id BIGINT NOT NULL,
    doctor_id BIGINT,
    admission_date DATETIME NOT NULL,
    discharge_date DATETIME,
    status VARCHAR(20) NOT NULL DEFAULT 'ADMITTED',
    CONSTRAINT fk_adm_patient FOREIGN KEY (patient_id) REFERENCES patient(id) ON DELETE CASCADE,
    CONSTRAINT fk_adm_room FOREIGN KEY (room_id) REFERENCES room(id),
    CONSTRAINT fk_adm_doctor FOREIGN KEY (doctor_id) REFERENCES doctor(id) ON DELETE SET NULL
);

-- ---------------- Billing ----------------
CREATE TABLE IF NOT EXISTS billing (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    patient_id BIGINT NOT NULL,
    admission_id BIGINT,
    amount DECIMAL(10,2) NOT NULL,
    billing_date DATETIME NOT NULL,
    payment_status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    CONSTRAINT fk_bill_patient FOREIGN KEY (patient_id) REFERENCES patient(id) ON DELETE CASCADE,
    CONSTRAINT fk_bill_admission FOREIGN KEY (admission_id) REFERENCES admission(id) ON DELETE SET NULL
);

-- ---------------- Prescriptions ----------------
CREATE TABLE IF NOT EXISTS prescription (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    appointment_id BIGINT NOT NULL,
    medicine_name VARCHAR(100) NOT NULL,
    dosage VARCHAR(100),
    notes VARCHAR(255),
    CONSTRAINT fk_pres_appointment FOREIGN KEY (appointment_id) REFERENCES appointment(id) ON DELETE CASCADE
);

-- ============================================================
-- Trigger: automatically mark a room OCCUPIED on admission
-- and AVAILABLE again once a discharge_date is set.
-- ============================================================
DELIMITER //

CREATE TRIGGER trg_room_occupied_after_admission
AFTER INSERT ON admission
FOR EACH ROW
BEGIN
    UPDATE room SET status = 'OCCUPIED' WHERE id = NEW.room_id;
END//

CREATE TRIGGER trg_room_available_after_discharge
AFTER UPDATE ON admission
FOR EACH ROW
BEGIN
    IF NEW.discharge_date IS NOT NULL AND OLD.discharge_date IS NULL THEN
        UPDATE room SET status = 'AVAILABLE' WHERE id = NEW.room_id;
    END IF;
END//

DELIMITER ;

-- ============================================================
-- Views
-- ============================================================

-- Patient billing summary
CREATE OR REPLACE VIEW vw_patient_billing_summary AS
SELECT p.id AS patient_id, p.name AS patient_name,
       COUNT(b.id) AS total_bills,
       SUM(b.amount) AS total_amount,
       SUM(CASE WHEN b.payment_status = 'PENDING' THEN b.amount ELSE 0 END) AS pending_amount
FROM patient p
LEFT JOIN billing b ON b.patient_id = p.id
GROUP BY p.id, p.name;

-- Doctor appointment load
CREATE OR REPLACE VIEW vw_doctor_appointment_load AS
SELECT d.id AS doctor_id, d.name AS doctor_name, dept.name AS department_name,
       COUNT(a.id) AS total_appointments
FROM doctor d
LEFT JOIN department dept ON d.department_id = dept.id
LEFT JOIN appointment a ON a.doctor_id = d.id
GROUP BY d.id, d.name, dept.name;

-- Currently occupied rooms with patient details
CREATE OR REPLACE VIEW vw_current_admissions AS
SELECT adm.id AS admission_id, p.name AS patient_name, r.room_number,
       doc.name AS attending_doctor, adm.admission_date
FROM admission adm
JOIN patient p ON adm.patient_id = p.id
JOIN room r ON adm.room_id = r.id
LEFT JOIN doctor doc ON adm.doctor_id = doc.id
WHERE adm.discharge_date IS NULL;
