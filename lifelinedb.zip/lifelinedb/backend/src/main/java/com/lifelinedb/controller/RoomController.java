package com.lifelinedb.controller;

import com.lifelinedb.entity.Room;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.RoomRepository;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    private final RoomRepository roomRepository;

    public RoomController(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    @GetMapping
    public List<Room> getAll(@RequestParam(required = false) String status) {
        if (status != null) {
            return roomRepository.findByStatus(status);
        }
        return roomRepository.findAll();
    }

    @GetMapping("/{id}")
    public Room getOne(@PathVariable Long id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id " + id));
    }

    @PostMapping
    public Room create(@Valid @RequestBody Room room) {
        room.setId(null);
        if (room.getStatus() == null || room.getStatus().isBlank()) {
            room.setStatus("Available");
        }
        return roomRepository.save(room);
    }

    @PutMapping("/{id}")
    public Room update(@PathVariable Long id, @Valid @RequestBody Room updated) {
        Room existing = roomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id " + id));
        existing.setRoomNumber(updated.getRoomNumber());
        existing.setRoomType(updated.getRoomType());
        existing.setStatus(updated.getStatus());
        existing.setPricePerDay(updated.getPricePerDay());
        return roomRepository.save(existing);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        if (!roomRepository.existsById(id)) {
            throw new ResourceNotFoundException("Room not found with id " + id);
        }
        roomRepository.deleteById(id);
    }
}
