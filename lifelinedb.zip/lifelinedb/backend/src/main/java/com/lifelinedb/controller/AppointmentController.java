package com.lifelinedb.controller;

import com.lifelinedb.dto.AppointmentRequest;
import com.lifelinedb.entity.Appointment;
import com.lifelinedb.entity.Doctor;
import com.lifelinedb.entity.Patient;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.AppointmentRepository;
import com.lifelinedb.repository.DoctorRepository;
import com.lifelinedb.repository.PatientRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {

    private final AppointmentRepository appointmentRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    public AppointmentController(AppointmentRepository appointmentRepository,
                                  PatientRepository patientRepository,
                                  DoctorRepository doctorRepository) {
        this.appointmentRepository = appointmentRepository;
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
    }

    @GetMapping
    public List<Appointment> getAll(@RequestParam(required = false) Long patientId,
                                     @RequestParam(required = false) Long doctorId) {
        if (patientId != null) return appointmentRepository.findByPatientId(patientId);
        if (doctorId != null) return appointmentRepository.findByDoctorId(doctorId);
        return appointmentRepository.findAll();
    }

    @GetMapping("/{id}")
    public Appointment getOne(@PathVariable Long id) {
        return appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id " + id));
    }

    @PostMapping
    public Appointment create(@RequestBody AppointmentRequest request) {
        Appointment appointment = new Appointment();
        applyRequest(appointment, request);
        return appointmentRepository.save(appointment);
    }

    @PutMapping("/{id}")
    public Appointment update(@PathVariable Long id, @RequestBody AppointmentRequest request) {
        Appointment existing = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id " + id));
        applyRequest(existing, request);
        return appointmentRepository.save(existing);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        if (!appointmentRepository.existsById(id)) {
            throw new ResourceNotFoundException("Appointment not found with id " + id);
        }
        appointmentRepository.deleteById(id);
    }

    private void applyRequest(Appointment appointment, AppointmentRequest request) {
        if (request.getPatientId() == null || request.getDoctorId() == null) {
            throw new IllegalArgumentException("patientId and doctorId are required");
        }
        Patient patient = patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id " + request.getPatientId()));
        Doctor doctor = doctorRepository.findById(request.getDoctorId())
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id " + request.getDoctorId()));

        appointment.setPatient(patient);
        appointment.setDoctor(doctor);
        appointment.setAppointmentDate(request.getAppointmentDate());
        appointment.setAppointmentTime(request.getAppointmentTime());
        appointment.setReason(request.getReason());
        if (request.getStatus() != null && !request.getStatus().isBlank()) {
            appointment.setStatus(request.getStatus());
        }
    }
}
