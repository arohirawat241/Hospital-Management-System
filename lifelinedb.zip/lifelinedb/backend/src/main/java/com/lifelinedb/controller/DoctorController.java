package com.lifelinedb.controller;

import com.lifelinedb.dto.DoctorRequest;
import com.lifelinedb.entity.Department;
import com.lifelinedb.entity.Doctor;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.DepartmentRepository;
import com.lifelinedb.repository.DoctorRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {

    private final DoctorRepository doctorRepository;
    private final DepartmentRepository departmentRepository;

    public DoctorController(DoctorRepository doctorRepository, DepartmentRepository departmentRepository) {
        this.doctorRepository = doctorRepository;
        this.departmentRepository = departmentRepository;
    }

    @GetMapping
    public List<Doctor> getAll(@RequestParam(required = false) Long departmentId) {
        if (departmentId != null) {
            return doctorRepository.findByDepartmentId(departmentId);
        }
        return doctorRepository.findAll();
    }

    @GetMapping("/{id}")
    public Doctor getOne(@PathVariable Long id) {
        return doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id " + id));
    }

    @PostMapping
    public Doctor create(@RequestBody DoctorRequest request) {
        Doctor doctor = new Doctor();
        applyRequest(doctor, request);
        return doctorRepository.save(doctor);
    }

    @PutMapping("/{id}")
    public Doctor update(@PathVariable Long id, @RequestBody DoctorRequest request) {
        Doctor existing = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id " + id));
        applyRequest(existing, request);
        return doctorRepository.save(existing);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        if (!doctorRepository.existsById(id)) {
            throw new ResourceNotFoundException("Doctor not found with id " + id);
        }
        doctorRepository.deleteById(id);
    }

    private void applyRequest(Doctor doctor, DoctorRequest request) {
        if (request.getName() == null || request.getName().isBlank()) {
            throw new IllegalArgumentException("Doctor name is required");
        }
        doctor.setName(request.getName());
        doctor.setSpecialization(request.getSpecialization());
        doctor.setPhone(request.getPhone());
        doctor.setEmail(request.getEmail());

        if (request.getDepartmentId() != null) {
            Department department = departmentRepository.findById(request.getDepartmentId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Department not found with id " + request.getDepartmentId()));
            doctor.setDepartment(department);
        } else {
            doctor.setDepartment(null);
        }
    }
}
