package com.lifelinedb.controller;

import com.lifelinedb.dto.AdmissionRequest;
import com.lifelinedb.entity.Admission;
import com.lifelinedb.entity.Doctor;
import com.lifelinedb.entity.Patient;
import com.lifelinedb.entity.Room;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.AdmissionRepository;
import com.lifelinedb.repository.DoctorRepository;
import com.lifelinedb.repository.PatientRepository;
import com.lifelinedb.repository.RoomRepository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Handles hospital admissions. Mirrors the "trigger for automatic room status
 * updates" described in the project proposal: creating an admission marks the
 * room Occupied, and discharging a patient marks the room Available again.
 */
@RestController
@RequestMapping("/api/admissions")
public class AdmissionController {

    private final AdmissionRepository admissionRepository;
    private final PatientRepository patientRepository;
    private final RoomRepository roomRepository;
    private final DoctorRepository doctorRepository;

    public AdmissionController(AdmissionRepository admissionRepository,
                                PatientRepository patientRepository,
                                RoomRepository roomRepository,
                                DoctorRepository doctorRepository) {
        this.admissionRepository = admissionRepository;
        this.patientRepository = patientRepository;
        this.roomRepository = roomRepository;
        this.doctorRepository = doctorRepository;
    }

    @GetMapping
    public List<Admission> getAll(@RequestParam(required = false) Long patientId,
                                   @RequestParam(required = false) String status) {
        if (patientId != null) return admissionRepository.findByPatientId(patientId);
        if (status != null) return admissionRepository.findByStatus(status);
        return admissionRepository.findAll();
    }

    @GetMapping("/{id}")
    public Admission getOne(@PathVariable Long id) {
        return admissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Admission not found with id " + id));
    }

    @Transactional
    @PostMapping
    public Admission create(@RequestBody AdmissionRequest request) {
        if (request.getPatientId() == null || request.getRoomId() == null) {
            throw new IllegalArgumentException("patientId and roomId are required");
        }
        Patient patient = patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id " + request.getPatientId()));
        Room room = roomRepository.findById(request.getRoomId())
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id " + request.getRoomId()));

        if ("Occupied".equalsIgnoreCase(room.getStatus())) {
            throw new IllegalArgumentException("Room " + room.getRoomNumber() + " is already occupied");
        }

        Admission admission = new Admission();
        admission.setPatient(patient);
        admission.setRoom(room);
        admission.setAdmissionDate(request.getAdmissionDate());
        admission.setStatus("Admitted");

        if (request.getDoctorId() != null) {
            Doctor doctor = doctorRepository.findById(request.getDoctorId())
                    .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id " + request.getDoctorId()));
            admission.setDoctor(doctor);
        }

        // Trigger-equivalent: occupy the room on admission
        room.setStatus("Occupied");
        roomRepository.save(room);

        return admissionRepository.save(admission);
    }

    @Transactional
    @PutMapping("/{id}")
    public Admission update(@PathVariable Long id, @RequestBody AdmissionRequest request) {
        Admission existing = admissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Admission not found with id " + id));

        if (request.getDoctorId() != null) {
            Doctor doctor = doctorRepository.findById(request.getDoctorId())
                    .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id " + request.getDoctorId()));
            existing.setDoctor(doctor);
        }
        if (request.getAdmissionDate() != null) {
            existing.setAdmissionDate(request.getAdmissionDate());
        }
        if (request.getDischargeDate() != null) {
            existing.setDischargeDate(request.getDischargeDate());
        }
        if (request.getStatus() != null && !request.getStatus().isBlank()) {
            existing.setStatus(request.getStatus());
        }

        // Trigger-equivalent: freeing the room when a patient is discharged
        if ("Discharged".equalsIgnoreCase(existing.getStatus())) {
            Room room = existing.getRoom();
            room.setStatus("Available");
            roomRepository.save(room);
        }

        return admissionRepository.save(existing);
    }

    @Transactional
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        Admission existing = admissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Admission not found with id " + id));
        // Free up the room if it was still marked occupied for this admission
        if ("Admitted".equalsIgnoreCase(existing.getStatus())) {
            Room room = existing.getRoom();
            room.setStatus("Available");
            roomRepository.save(room);
        }
        admissionRepository.deleteById(id);
    }
}
