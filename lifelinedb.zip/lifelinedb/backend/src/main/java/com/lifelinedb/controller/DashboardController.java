package com.lifelinedb.controller;

import com.lifelinedb.repository.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final DepartmentRepository departmentRepository;
    private final AppointmentRepository appointmentRepository;
    private final RoomRepository roomRepository;
    private final AdmissionRepository admissionRepository;
    private final BillingRepository billingRepository;
    private final PrescriptionRepository prescriptionRepository;

    public DashboardController(PatientRepository patientRepository,
                                DoctorRepository doctorRepository,
                                DepartmentRepository departmentRepository,
                                AppointmentRepository appointmentRepository,
                                RoomRepository roomRepository,
                                AdmissionRepository admissionRepository,
                                BillingRepository billingRepository,
                                PrescriptionRepository prescriptionRepository) {
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
        this.departmentRepository = departmentRepository;
        this.appointmentRepository = appointmentRepository;
        this.roomRepository = roomRepository;
        this.admissionRepository = admissionRepository;
        this.billingRepository = billingRepository;
        this.prescriptionRepository = prescriptionRepository;
    }

    @GetMapping("/summary")
    public Map<String, Object> summary() {
        Map<String, Object> summary = new HashMap<>();
        summary.put("patients", patientRepository.count());
        summary.put("doctors", doctorRepository.count());
        summary.put("departments", departmentRepository.count());
        summary.put("appointments", appointmentRepository.count());
        summary.put("rooms", roomRepository.count());
        summary.put("roomsAvailable", roomRepository.findByStatus("Available").size());
        summary.put("roomsOccupied", roomRepository.findByStatus("Occupied").size());
        summary.put("activeAdmissions", admissionRepository.findByStatus("Admitted").size());
        summary.put("prescriptions", prescriptionRepository.count());

        double pendingRevenue = billingRepository.findAll().stream()
                .filter(b -> "Pending".equalsIgnoreCase(b.getPaymentStatus()))
                .mapToDouble(b -> b.getAmount() == null ? 0 : b.getAmount())
                .sum();
        double collectedRevenue = billingRepository.findAll().stream()
                .filter(b -> "Paid".equalsIgnoreCase(b.getPaymentStatus()))
                .mapToDouble(b -> b.getAmount() == null ? 0 : b.getAmount())
                .sum();
        summary.put("pendingRevenue", pendingRevenue);
        summary.put("collectedRevenue", collectedRevenue);

        return summary;
    }
}
