package com.lifelinedb.controller;

import com.lifelinedb.dto.PrescriptionRequest;
import com.lifelinedb.entity.Appointment;
import com.lifelinedb.entity.Doctor;
import com.lifelinedb.entity.Patient;
import com.lifelinedb.entity.Prescription;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.AppointmentRepository;
import com.lifelinedb.repository.DoctorRepository;
import com.lifelinedb.repository.PatientRepository;
import com.lifelinedb.repository.PrescriptionRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/prescriptions")
public class PrescriptionController {

    private final PrescriptionRepository prescriptionRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final AppointmentRepository appointmentRepository;

    public PrescriptionController(PrescriptionRepository prescriptionRepository,
                                   PatientRepository patientRepository,
                                   DoctorRepository doctorRepository,
                                   AppointmentRepository appointmentRepository) {
        this.prescriptionRepository = prescriptionRepository;
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
        this.appointmentRepository = appointmentRepository;
    }

    @GetMapping
    public List<Prescription> getAll(@RequestParam(required = false) Long patientId) {
        if (patientId != null) return prescriptionRepository.findByPatientId(patientId);
        return prescriptionRepository.findAll();
    }

    @GetMapping("/{id}")
    public Prescription getOne(@PathVariable Long id) {
        return prescriptionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Prescription not found with id " + id));
    }

    @PostMapping
    public Prescription create(@RequestBody PrescriptionRequest request) {
        Prescription prescription = new Prescription();
        applyRequest(prescription, request);
        return prescriptionRepository.save(prescription);
    }

    @PutMapping("/{id}")
    public Prescription update(@PathVariable Long id, @RequestBody PrescriptionRequest request) {
        Prescription existing = prescriptionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Prescription not found with id " + id));
        applyRequest(existing, request);
        return prescriptionRepository.save(existing);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        if (!prescriptionRepository.existsById(id)) {
            throw new ResourceNotFoundException("Prescription not found with id " + id);
        }
        prescriptionRepository.deleteById(id);
    }

    private void applyRequest(Prescription prescription, PrescriptionRequest request) {
        if (request.getPatientId() == null || request.getDoctorId() == null) {
            throw new IllegalArgumentException("patientId and doctorId are required");
        }
        Patient patient = patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id " + request.getPatientId()));
        Doctor doctor = doctorRepository.findById(request.getDoctorId())
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with id " + request.getDoctorId()));

        prescription.setPatient(patient);
        prescription.setDoctor(doctor);
        prescription.setMedicineName(request.getMedicineName());
        prescription.setDosage(request.getDosage());
        prescription.setNotes(request.getNotes());
        prescription.setPrescriptionDate(request.getPrescriptionDate());

        if (request.getAppointmentId() != null) {
            Appointment appointment = appointmentRepository.findById(request.getAppointmentId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Appointment not found with id " + request.getAppointmentId()));
            prescription.setAppointment(appointment);
        } else {
            prescription.setAppointment(null);
        }
    }
}
