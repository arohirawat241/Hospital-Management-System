package com.lifelinedb.controller;

import com.lifelinedb.dto.BillingRequest;
import com.lifelinedb.entity.Admission;
import com.lifelinedb.entity.Billing;
import com.lifelinedb.entity.Patient;
import com.lifelinedb.exception.ResourceNotFoundException;
import com.lifelinedb.repository.AdmissionRepository;
import com.lifelinedb.repository.BillingRepository;
import com.lifelinedb.repository.PatientRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/billing")
public class BillingController {

    private final BillingRepository billingRepository;
    private final PatientRepository patientRepository;
    private final AdmissionRepository admissionRepository;

    public BillingController(BillingRepository billingRepository,
                              PatientRepository patientRepository,
                              AdmissionRepository admissionRepository) {
        this.billingRepository = billingRepository;
        this.patientRepository = patientRepository;
        this.admissionRepository = admissionRepository;
    }

    @GetMapping
    public List<Billing> getAll(@RequestParam(required = false) Long patientId) {
        if (patientId != null) return billingRepository.findByPatientId(patientId);
        return billingRepository.findAll();
    }

    @GetMapping("/{id}")
    public Billing getOne(@PathVariable Long id) {
        return billingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Billing record not found with id " + id));
    }

    @PostMapping
    public Billing create(@RequestBody BillingRequest request) {
        Billing billing = new Billing();
        applyRequest(billing, request);
        return billingRepository.save(billing);
    }

    @PutMapping("/{id}")
    public Billing update(@PathVariable Long id, @RequestBody BillingRequest request) {
        Billing existing = billingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Billing record not found with id " + id));
        applyRequest(existing, request);
        return billingRepository.save(existing);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        if (!billingRepository.existsById(id)) {
            throw new ResourceNotFoundException("Billing record not found with id " + id);
        }
        billingRepository.deleteById(id);
    }

    private void applyRequest(Billing billing, BillingRequest request) {
        if (request.getPatientId() == null || request.getAmount() == null) {
            throw new IllegalArgumentException("patientId and amount are required");
        }
        Patient patient = patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id " + request.getPatientId()));
        billing.setPatient(patient);
        billing.setAmount(request.getAmount());
        billing.setBillDate(request.getBillDate());
        billing.setDescription(request.getDescription());
        if (request.getPaymentStatus() != null && !request.getPaymentStatus().isBlank()) {
            billing.setPaymentStatus(request.getPaymentStatus());
        }

        if (request.getAdmissionId() != null) {
            Admission admission = admissionRepository.findById(request.getAdmissionId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Admission not found with id " + request.getAdmissionId()));
            billing.setAdmission(admission);
        } else {
            billing.setAdmission(null);
        }
    }
}
