package com.lifelinedb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifeLineDbApplication {

    public static void main(String[] args) {
        SpringApplication.run(LifeLineDbApplication.class, args);
        System.out.println("========================================");
        System.out.println(" LifeLineDB backend running on port 8080");
        System.out.println(" API base: http://localhost:8080/api");
        System.out.println("========================================");
    }
}
