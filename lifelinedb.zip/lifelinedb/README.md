# LifeLineDB — Healthcare Management System
Spring Boot + MySQL implementation of the LifeLineDB hospital database project.

## Tech stack
- Java 17
- Spring Boot 3.3.4 (Web, Data JPA, Validation)
- MySQL 8
- Maven
- Lombok

## Project structure
```
lifelinedb/
├── pom.xml
├── database/
│   └── schema.sql          # Reference DDL: tables, FKs, triggers, views (optional — Hibernate can create the schema for you)
├── src/main/java/com/lifelinedb/
│   ├── LifelinedbApplication.java
│   ├── entity/              # Department, Doctor, Patient, Room, Appointment, Admission, Billing, Prescription
│   ├── repository/          # Spring Data JPA repositories
│   ├── service/              # Business logic (incl. room-status trigger equivalent)
│   ├── controller/            # REST controllers
│   └── exception/            # Global exception handling
└── src/main/resources/
    └── application.properties
```

## 1. Set up MySQL
Create a database user/password or use root, then either:

**Option A — let Hibernate create the schema (default, easiest)**
Just make sure the DB exists (or let the connection string auto-create it) — `application.properties` already has:
```
spring.datasource.url=jdbc:mysql://localhost:3306/lifelinedb?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC
spring.jpa.hibernate.ddl-auto=update
```

**Option B — run the reference DDL yourself** (includes triggers + views from the project report)
```bash
mysql -u root -p < database/schema.sql
```
If you use this option, set `spring.jpa.hibernate.ddl-auto=validate` in `application.properties` afterward so Hibernate doesn't try to alter your hand-built schema.

## 2. Configure credentials
Edit `src/main/resources/application.properties`:
```
spring.datasource.username=root
spring.datasource.password=your_mysql_password
```

## 3. Run
```bash
mvn spring-boot:run
```
The API starts on `http://localhost:8080`.

## API endpoints

| Resource | Endpoints |
|---|---|
| Departments | `GET/POST /api/departments`, `GET/PUT/DELETE /api/departments/{id}` |
| Doctors | `GET/POST /api/doctors`, `GET/PUT/DELETE /api/doctors/{id}`, `GET /api/doctors/department/{departmentId}` |
| Patients | `GET/POST /api/patients`, `GET/PUT/DELETE /api/patients/{id}` |
| Rooms | `GET/POST /api/rooms`, `GET/PUT/DELETE /api/rooms/{id}`, `GET /api/rooms/available` |
| Appointments | `GET/POST /api/appointments`, `GET/PUT/DELETE /api/appointments/{id}`, `GET /api/appointments/patient/{id}`, `GET /api/appointments/doctor/{id}` |
| Admissions | `GET/POST /api/admissions`, `GET/DELETE /api/admissions/{id}`, `GET /api/admissions/current`, `GET /api/admissions/patient/{id}`, `PUT /api/admissions/{id}/discharge` |
| Billing | `GET/POST /api/billing`, `GET/PUT/DELETE /api/billing/{id}`, `GET /api/billing/patient/{id}` |
| Prescriptions | `GET/POST /api/prescriptions`, `GET/PUT/DELETE /api/prescriptions/{id}`, `GET /api/prescriptions/appointment/{id}` |

## Sample requests

**Create a department**
```bash
curl -X POST http://localhost:8080/api/departments \
  -H "Content-Type: application/json" \
  -d '{"name":"Cardiology","description":"Heart and vascular care"}'
```

**Create a doctor**
```bash
curl -X POST http://localhost:8080/api/doctors \
  -H "Content-Type: application/json" \
  -d '{"name":"Dr. Asha Rao","specialization":"Cardiologist","phone":"9876543210","email":"asha.rao@lifelinedb.com","department":{"id":1}}'
```

**Create a patient**
```bash
curl -X POST http://localhost:8080/api/patients \
  -H "Content-Type: application/json" \
  -d '{"name":"Rahul Verma","dateOfBirth":"1990-05-14","gender":"Male","phone":"9998887770","address":"Bengaluru","email":"rahul@example.com"}'
```

**Create a room**
```bash
curl -X POST http://localhost:8080/api/rooms \
  -H "Content-Type: application/json" \
  -d '{"roomNumber":"101A","roomType":"General","pricePerDay":1500.00}'
```

**Book an appointment**
```bash
curl -X POST http://localhost:8080/api/appointments \
  -H "Content-Type: application/json" \
  -d '{"patient":{"id":1},"doctor":{"id":1},"appointmentDate":"2026-07-10T10:30:00","reason":"Routine checkup"}'
```

**Admit a patient** (automatically flips the room to OCCUPIED)
```bash
curl -X POST http://localhost:8080/api/admissions \
  -H "Content-Type: application/json" \
  -d '{"patient":{"id":1},"room":{"id":1},"doctor":{"id":1},"admissionDate":"2026-07-10T09:00:00"}'
```

**Discharge a patient** (automatically flips the room back to AVAILABLE)
```bash
curl -X PUT http://localhost:8080/api/admissions/1/discharge
```

**Add a bill**
```bash
curl -X POST http://localhost:8080/api/billing \
  -H "Content-Type: application/json" \
  -d '{"patient":{"id":1},"admission":{"id":1},"amount":4500.00,"billingDate":"2026-07-12T12:00:00"}'
```

**Add a prescription**
```bash
curl -X POST http://localhost:8080/api/prescriptions \
  -H "Content-Type: application/json" \
  -d '{"appointment":{"id":1},"medicineName":"Atorvastatin","dosage":"10mg once daily","notes":"Take after dinner"}'
```

## Notes on how this maps to the project report
- **Normalization (3NF) / relational schema** → JPA entities with `@ManyToOne` foreign keys (Doctor→Department, Appointment→Patient/Doctor, Admission→Patient/Room/Doctor, Billing→Patient/Admission, Prescription→Appointment).
- **Constraints** → `@NotBlank`/`@NotNull` bean validation on the Java side, plus `NOT NULL`/`UNIQUE`/`FOREIGN KEY` constraints in `database/schema.sql`.
- **Triggers** (auto room-status updates) → implemented as application-layer logic in `AdmissionService.create()` / `.discharge()`, and also included as real MySQL `TRIGGER`s in `database/schema.sql` if you'd rather enforce it at the DB level.
- **Views** → `vw_patient_billing_summary`, `vw_doctor_appointment_load`, `vw_current_admissions` in `database/schema.sql` (query them directly with any MySQL client; wiring a `@Query` for a native view is a natural next step if you want them exposed via the API).
- **GUI** → the original plan used Tkinter/Flask; here the GUI layer is replaced by this REST API, which any frontend (React, Postman, curl, mobile app) can consume.
